letters = ('A', 'B', 'C', 'D', 'E', 'J', 'K')

boolean = {False: False, True: True}